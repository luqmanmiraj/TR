
#!/bin/bash
# Check if python is installed
if command -v python3 &>/dev/null; then
    echo "Python is already installed"
else
    echo "Python is not installed. Installing Python..."
    sudo apt update
    sudo apt install python3 -y
fi

# Check if pip is installed
if command -v pip &>/dev/null; then
    echo "pip is already installed"
else
    echo "pip is not installed. Installing pip..."
    sudo apt-get install python3-pip -y
fi

echo "Python and pip installation completed"
# pip n modules
# Check if the pip module is installed.
if ! [ -x "$(command -v pip)" ]; then
  echo "pip is not installed."
  exit 1
fi
# Check if the module is installed.
# Declare an array of  pip modules
modules=(
    "boto3"
    "pyautogui"
    "pynput"
    "requests"
)

# Loop through the array
for module in "${modules[@]}"
do
  if ! pip show $module; then
    echo "The $module module is not installed."
    echo "Installing..."
    pip install $module
  fi
done


# Check if the module is installed successfully.
for module in "${modules[@]}"
do
  if pip show $module; then
    echo "The $module module is installed successfully."
  else
    echo "Failed to install the $module module."
    exit 1
  fi
done











if pgrep -f " a.py" >/dev/null
then
  echo "The a.py script is running."
  echo "stoping it"
  pkill -f a.py
else
  echo "The a.py script is not running."
fi


if pgrep -f " b.py" >/dev/null
then
  echo "The b.py script is running."
  echo "stoping it"
  pkill -f b.py
else
  echo "The b.py script is not running."
fi


if pgrep -f " d.py" >/dev/null
then
  echo "The d.py script is running."
  echo "stoping it"
  pkill -f d.py
else
  echo "The d.py script is not running."
fi


if pgrep -f " m.py" >/dev/null
then
  echo "The m.py script is running."
  echo "stoping it"
  pkill -f m.py
else
  echo "The m.py script is not running."
fi


if pgrep -f " s.py" >/dev/null
then
  echo "The s.py script is running."
  echo "stoping it"
  pkill -f s.py
else
  echo "The s.py script is not running."
fi
# Keyword to filter processes
# keyword="m.py"

# # Find processes containing the keyword
# processes=$(ps -ax | grep $keyword )
# echo $processes

# # Loop through each process and terminate it
# for process in $processes; do
#     # Get the process ID (PID)
#     pid=$(echo $process | awk '{print $2}')
    
#     # Terminate the process
#     echo "Terminating process $pid..."
#     kill $pid
# done

python a.py &
python b.py &
python d.py &
python m.py &
python s.py &



