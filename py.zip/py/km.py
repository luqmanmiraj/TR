
from pynput import keyboard, mouse

# Counter variables
keyboard_count = 0
mouse_count = 0

# Keyboard press event listener
def on_keyboard_press(key):
    global keyboard_count
    keyboard_count += 1
    print(keyboard_count)

# Mouse press event listener
def on_mouse_click(x, y, button, pressed):
    global mouse_count
    mouse_count += 1
    print(mouse_count)

# Create keyboard listener
keyboard_listener = keyboard.Listener(on_press=on_keyboard_press)
keyboard_listener.start()

# Create mouse listener
mouse_listener = mouse.Listener(on_click=on_mouse_click)
mouse_listener.start()

# Run the program
while True:
    pass

# Stop the listeners
keyboard_listener.stop()
mouse_listener.stop()

# Print the counts
print('Keyboard presses:', keyboard_count)
print('Mouse presses:', mouse_count)
