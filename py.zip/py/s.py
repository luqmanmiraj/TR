import boto3
import os
import time

def get_username():
    if os.name == "nt":
        return os.getenv("USERNAME")
    elif os.name == "posix":
        return os.getenv("USER")
    else:
        return "unknown"
print(get_username())
# S3 bucket details
bucket_name = "tekjintracking"
timestamp = time.strftime("%y-%m-%d", time.localtime())

folder_path = "sc_"+get_username()+"/"+timestamp
print(timestamp)
# Function to upload file to S3 bucket
def upload_file(filename):
    s3 = boto3.client('s3')
    try:
        s3.upload_file(filename, bucket_name, os.path.join(folder_path, filename))
        print(f"{filename} uploaded successfully.")
        return True
    except Exception as e:
        print(e)
        return False

# Function to delete file from local directory
def delete_file(filename):
    os.remove(filename)
    print(f"{filename} deleted successfully.")

# Function to list all files in local directory
def list_files():
    files = os.listdir()
    return files

# Main function to continuously upload and delete files
def main():
    while True:
        files = list_files()
        print(files)
        for file in files:
            if file.endswith(".png"):
                if upload_file(file):
                    delete_file(file)
                else:
                    time.sleep(300)

        time.sleep(600)  # Wait for 600 seconds before the next iteration
if __name__ == "__main__":
    main()