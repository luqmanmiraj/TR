
from pynput.mouse import Listener
def on_click(x, y, button, pressed):
    if pressed:
        append_data("1")
def append_data(data):
    with open("m.txt", "a") as f:
        f.write(data)
listener = Listener(on_click=on_click)
listener.start()

# Start the main event loop
listener.join()
