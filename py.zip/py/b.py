
import pyautogui
import time
def take_screenshot():
    cnt = count_chars("data.txt")
    mclicks = count_clicks("m.txt")
    timestamp = time.strftime(str(cnt) + "k"+ str(mclicks)+"m"+"%y-%m-%d_%H-%M-%S", time.localtime())
    screenshot = pyautogui.screenshot()
    screenshot.save(f"{timestamp}.png")
    make_file_empty("data.txt")
def count_chars(filename):
  """Count the number of characters in a text file."""
  with open(filename, 'r') as f:
    contents = f.read()
    append_data(contents)
  return len(contents)
def count_clicks(filename):
  """Count the number of characters in a text file."""
  with open(filename, 'r') as f:
    contents = f.read()
    make_file_empty('m.txt')
  return len(contents)
def append_data(data):
    with open("big.txt", "a") as f:
        timestamp = time.strftime("%y-%m-%d_%H-%M-%S", time.localtime())
        f.write(timestamp + "::: " + data + "\n")
def make_file_empty(file_path):
    with open(file_path, 'w') as file:
        pass

while True:
    take_screenshot() 
    timetosleep = 300
    with open("con.txt", 'r') as f:
      contents = f.read()
      print(contents)
      timetosleep = int(contents)
    time.sleep(timetosleep)

